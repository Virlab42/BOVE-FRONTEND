"use client";
import Link from "next/link";
import "./Catalog.scss";
import { useState, useEffect } from "react";
import { useCategories } from "@/hooks/useCategories"
import Image from "next/image";
import { useFavourite } from "@/context/FavouriteContext";

function buildProductUrl(productName, colorName, id) {
  const translitMap = {
    а: "a", б: "b", в: "v", г: "g", д: "d",
    е: "e", ё: "e", ж: "zh", з: "z", и: "i",
    й: "i", к: "k", л: "l", м: "m", н: "n",
    о: "o", п: "p", р: "r", с: "s", т: "t",
    у: "u", ф: "f", х: "h", ц: "c", ч: "ch",
    ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "",
    э: "e", ю: "yu", я: "ya"
  };

  const translit = (str) =>
    str
      .toLowerCase()
      .split("")
      .map((char) => translitMap[char] ?? char)
      .join("");

  const slugify = (str) =>
    translit(str)
      .replace(/[^a-z0-9\s-]/g, "")   // убрать мусор
      .trim()
      .replace(/\s+/g, "-")           // пробелы → "-"
      .replace(/-+/g, "-");           // убрать двойные дефисы

  const productSlug = slugify(productName);
  const colorSlug = slugify(colorName);

  return `${productSlug}-${colorSlug}-${id}`;
}

export default function Catalog({ initialCat }) {
  const [selectedCat, setSelectedCat] = useState(initialCat);
  const [sortType, setSortType] = useState("new");
  const [favorites, setFavorites] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const { data } = useCategories()
  const { toggleFavourite, isFavourite } = useFavourite();

  const API_URL = process.env.NEXT_PUBLIC_API_URL;
  // === НОРМАЛИЗАЦИЯ ВАРИАНТОВ ===============================================
  const normalizeVariantImages = (variant) => {
    if (!variant.image) return [];

    if (Array.isArray(variant.image)) return variant.image;

    if (typeof variant.image === "string") {
      return variant.image
        .split(",")
        .map((img) => img.trim())
        .filter(Boolean);
    }

    return [];
  };

  const normalizeProduct = (p) => ({
    ...p,
    available_sizes:
      typeof p.available_sizes_id === "string"
        ? JSON.parse(p.available_sizes_id)
        : [],

    variants: (p.variants || []).map((v) => ({
      ...v,
      images: normalizeVariantImages(v),
    })),
  });

  // === ЗАГРУЗКА ТОВАРОВ ======================================================
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);

        const res = await fetch(`${API_URL}/productsV3`);
        if (!res.ok) throw new Error("Ошибка загрузки товаров");

        const data = await res.json();
        const cleaned = (data.products || []).map(normalizeProduct);

        setProducts(cleaned);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  // === ФИЛЬТР ================================================================
  const filtered = selectedCat
    ? products.filter((p) => p.category_id === selectedCat)
    : products;

  // === СОРТИРОВКА ============================================================
  const sorted = [...filtered].sort((a, b) => {
    if (sortType === "cheap") return a.base_price - b.base_price;
    if (sortType === "expensive") return b.base_price - a.base_price;
    if (sortType === "new") return b.id - a.id;
    return 0;
  });

  // === РАЗВОРОТ 1 ЦВЕТ = 1 КАРТОЧКА ==========================================
  const flattened = sorted.flatMap((p) =>
    p.variants.map((v) => ({
      product_id: p.id,
      variant_id: v.id,
      full_name: p.full_name,
      category_id: p.category_id,
      price: p.base_price,
      color: v.color,
      name_for_colors: v.name_for_colors,
      hex_color: v.hex_color,
      images: v.images,
    }))
  );

  const getProductImage = (product) => {
    if (product.images?.length) return `${API_URL}/` + product.images[0];
    return "/placeholder.jpg";
  };

  // === РЕНДЕР ================================================================
  if (loading)
    return <div className="catalog"><div className="loading">Загрузка...</div></div>;

  if (error)
    return <div className="catalog"><div className="error">{error}</div></div>;

  return (
    <div className="catalog">

      {/* Мобильный фильтр */}
      <div className="catalog__filter__mob">
        <div>

          {isFilterOpen && (
            <ul className="filter-list" >
              {data?.categories?.map((c) => (
                <li
                  key={c.id}
                  className={c.id === selectedCat ? "active" : ""}
                  onClick={() => {
                    setSelectedCat(c.id === selectedCat ? null : c.id);
                    setIsFilterOpen(false);
                  }}
                >
                  {c.name}
                </li>
              ))}
            </ul>
          )}
          <button
            className="filter-toggle"
            onClick={() => setIsFilterOpen((prev) => !prev)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024"><title>Menu-unfold-outlined SVG Icon</title><path fill="currentColor" d="M408 442h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8m-8 204c0 4.4 3.6 8 8 8h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8zm504-486H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8m0 632H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8M142.4 642.1L298.7 519a8.84 8.84 0 0 0 0-13.9L142.4 381.9c-5.8-4.6-14.4-.5-14.4 6.9v246.3a8.9 8.9 0 0 0 14.4 7" /></svg>
            Категории
            {selectedCat && <span className="selected-dot" />}
          </button></div>

        <select value={sortType} onChange={(e) => setSortType(e.target.value)}>
          <option value="new">Сначала новинки</option>
          <option value="cheap">Сначала недорогие</option>
          <option value="expensive">Сначала дорогие</option>
        </select>
      </div>

      {/* Левый сайдбар */}
      <aside className="catalog__filter">
        <ul>
          {data?.categories?.map((c) => (
            <li
              key={c.id}
              className={c.id === selectedCat ? "active" : ""}
              onClick={() =>
                setSelectedCat(c.id === selectedCat ? null : c.id)
              }
            >
              {c.name}
            </li>
          ))}
        </ul>
      </aside>

      {/* Сетка товаров */}
      <div className="catalog__content">
        <div className="catalog__grid">
          {flattened.map((product) => (
            <Link
              href={`/catalog/${buildProductUrl(product.full_name, product.color, product.product_id)}?id=${product.product_id}&variant_id=${product.variant_id}`}
              className="product-card"
              key={`${product.product_id}-${product.color}`}
            >
              <div className="product-card__img">
                <Image width={1000} height={1000}
                  src={getProductImage(product)}
                  alt={product.full_name}
                />

                <button
                  className="favourite-button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleFavourite({
                      id: product.variant_id,
                      name: product.full_name,
                      colorName: product.color,
                      img: getProductImage(product),
                      productId: product.product_id,
                      price: product.price
                    });
                  }}
                >

                  {isFavourite(product.variant_id) ? (
                    // заполненное сердечко
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
                      <path fill="#c42b1c" stroke="#c42b1c" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16C1 12 2 6 7 4s8 2 9 4c1-2 5-6 10-4s5 8 2 12s-12 12-12 12s-9-8-12-12" />
                    </svg>
                  ) : (
                    // пустое сердечко
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
                      <path fill="transparent" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16C1 12 2 6 7 4s8 2 9 4c1-2 5-6 10-4s5 8 2 12s-12 12-12 12s-9-8-12-12" />
                    </svg>
                  )}
                </button>
              </div>

              <div className="product-card__title">{product.full_name} {product.name_for_colors}</div>
              <div className="product-card__price">
                {product.price > 0 ? `${parseInt(product.price)} ₽` : "Скоро будет"}
              </div>
            </Link>
          ))}

          {flattened.length === 0 && (
            <div className="catalog__empty">Нет товаров</div>
          )}
        </div>
      </div>

      {/* Правый сайдбар */}
      <aside className="catalog__sort">
        <select value={sortType} onChange={(e) => setSortType(e.target.value)}>
          <option value="new">Сначала новинки</option>
          <option value="cheap">Сначала недорогие</option>
          <option value="expensive">Сначала дорогие</option>
        </select>
      </aside>
    </div>
  );
}
